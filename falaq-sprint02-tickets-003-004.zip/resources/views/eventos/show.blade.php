@extends('layouts.app')

@section('content')
<div class="container mx-auto px-4 py-8">
    <h1 class="text-2xl font-bold mb-6">{{ $evento->titulo ?? 'Perguntas do Evento' }}</h1>

    <div class="space-y-4">
        @forelse ($perguntas as $pergunta)
            <div class="p-4 bg-white rounded-lg shadow border border-gray-200">
                <p class="text-gray-800 text-lg">{{ $pergunta->conteudo }}</p>
                <div class="mt-2 text-sm text-gray-500 flex justify-between items-center">
                    <span>
                        Postado por: <strong>{{ $pergunta->user->name ?? 'Anônimo' }}</strong>
                    </span>
                    <span>{{ $pergunta->created_at?->diffForHumans() }}</span>
                </div>
            </div>
        @empty
            <p class="text-gray-500">Nenhuma pergunta enviada ainda.</p>
        @endforelse
    </div>

    <div class="mt-6">
        {{ $perguntas->links() }}
    </div>
</div>
@endsection
