<?php

namespace App\Http\Controllers;

use App\Models\Evento;
use Illuminate\Http\Request;

class EventoController extends Controller
{
    public function show(Request $request, Evento $evento)
    {
        $perguntas = $evento->perguntas()
            ->where('is_public', true)
            ->with('user')
            ->when($request->filled('filtro'), function ($query) use ($request) {
                $query->where('status', $request->filtro);
            })
            ->latest()
            ->paginate(10);

        return view('eventos.show', compact('evento', 'perguntas'));
    }
}
